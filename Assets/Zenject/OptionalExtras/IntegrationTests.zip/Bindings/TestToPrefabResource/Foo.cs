﻿using UnityEngine;

namespace Zenject.Tests.ToPrefabResource
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
